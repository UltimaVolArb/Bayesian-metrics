% This is the main run file for estimating the unobserved components models
% in Grant and Chan (2016). It also computes the corresponding marginal
% likelihood.
%
% This code is free to use for academic purposes only, provided that the 
% paper is cited as:
%
% Grant, A.L. and Chan, J.C.C. (2017). A Bayesian Model Comparison for 
% Trend-Cycle Decompositions of Output, Journal of Money, Credit and Banking,
% 49(2-3): 525-552
%
% This code comes without technical support of any kind.  It is expected to
% reproduce the results reported in the paper. Under no circumstances will
% the authors be held responsible for any use (or misuse) of this code in
% any way.

clear; clc;
% 1: DT; 2: UC0; 3: UCUR; 4: DT-t0; 5: UCUR-t0; 
% 6: UCUR-(t0,t1); 
% 7: bivariate UCUR with one break + unemployment
% 8: bivariate UCUR with one break + inflation
model = 5; 
cp_ml = 1;      % 1: compute marginal likelihood 
nsims = 10000; %it was 100000
burnin = 1000; %it was 10000
M = 5000;      % number of replications in ML estimation and was 50000

%% load data
load 'JPNGDP.csv';  % 1960Q1-2018Q4
if model<= 8 % univariate models
    y = 100*log(JPNGDP);
    T = length(y);
    tid = linspace(1960,2018.75,T)';
        % break dates
    %t0 = 0;      % Bubble in Japan 1986:Q1
    %t0 = 105;    %this tid is asset bubble in japan 1986
    t0 = 189;     % 2007:Q1 
    % t0 = 241;     % 2007:Q1 
    % t0 = 245;     % 2008:Q1 
    % t0 = 249;     % 2009:Q1
    %t1 = 189; %one break for bivariate model
    %t1 = 241; %joshua's
    %t1 = 189; %the second break GFC in Japan
else % bivariate model
    load 'JPNURATE.csv'; % 1960Q1-2018Q4    
    load 'JPNCPI.csv';   % 1960Q1-2018Q4    
    if model == 8
            % use unemployment
        T = length(JPNURATE);
        y = reshape([100*log(JPNGDP(5:end)) JPNURATE]',T*2,1);
    else
            % use inflation 
        T = length(JPNCPI(4:end));
        y = reshape([100*log(JPNGDP(5:end)) JPNCPI(4:end)]',T*2,1);
    end
   % t0 = 189;   % 2006:Q1 (start from 1961Q1)
    %tid = linspace(1961,2018.75,T)';    
end

switch model
    case 1 
        DT;        
    case 2        
        UC0;        
    case 3
        UCUR;        
    case 4
        DT_break;      
    case 5
        UCUR_break;        
    case 6
        UCUR_break2;
    case {7, 8}
        biUCUR_break;
end    