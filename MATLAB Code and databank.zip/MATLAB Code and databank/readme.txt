This zip file contains Matlab code for replicating the empirical
examples in Grant and Chan (2017). The main file is:

main_UC.m 

This code is free to use for academic purposes only, provided that the 
paper is cited as:

Grant, A.L. and Chan, J.C.C. (2017). A Bayesian Model Comparison for 
Trend-Cycle Decompositions of Output, Journal of Money, Credit and Banking,
49(2-3): 525-552

This code comes without technical support of any kind. It is expected to
reproduce the results reported in the paper. Under no circumstances will
the author be held responsible for any use (or misuse) of this code in any way.